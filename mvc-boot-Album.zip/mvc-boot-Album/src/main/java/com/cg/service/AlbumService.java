package com.cg.service;

import com.cg.entity.Album;

public interface AlbumService {

	void addAlbum(Album a);

	Album getAlbum(int id);

	Iterable<Album> getAll();

	public String deleteAlbum(int id);

	public Album updateAlbum(Album a, int id);

}
