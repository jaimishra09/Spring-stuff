package com.cg.repo;

import org.springframework.data.repository.CrudRepository;

import com.cg.entity.Album;

public interface AlbumRepo extends CrudRepository<Album, Integer> {

}
