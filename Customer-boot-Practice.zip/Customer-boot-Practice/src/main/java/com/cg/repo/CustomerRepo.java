package com.cg.repo;

import org.springframework.data.repository.CrudRepository;

import com.cg.entity.Customer;

public interface CustomerRepo extends CrudRepository<Customer, Integer> {

}
