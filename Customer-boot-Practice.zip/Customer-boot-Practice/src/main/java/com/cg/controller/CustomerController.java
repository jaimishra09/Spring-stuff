package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Customer;
import com.cg.service.CustomerService;

@RestController
public class CustomerController {
	
	
	@Autowired
	private CustomerService service;
	
	@GetMapping("/info")
	public String get() {
		return "Welcome to boot Spring Jai";
	}
	
	@GetMapping("/display")
	public Iterable<Customer> getAll() {
		return service.getAll();
	}
	
	@PostMapping(path="/add", consumes="application/json")
	public String saveCustomer(@RequestBody Customer c) {
		service.saveCustomer(c);
		return "Customer Saved";
	}
	
	@GetMapping(name="/getid" , produces="application/json")
	public Customer getCustomer(@RequestParam("id") int id) {
		Customer c = service.get(id);
		return c;
	}
	
	@PutMapping(path="/update/{id}" , consumes = "application/json")
	public Customer update(@PathVariable("id") int id , @RequestBody Customer c) {
		return service.update(c, id);
	}
	
	@DeleteMapping(path="delete/{id}")
	public String delete(@PathVariable("id") int id) {
		return service.deleteCustomer(id);
	}
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
	
}
